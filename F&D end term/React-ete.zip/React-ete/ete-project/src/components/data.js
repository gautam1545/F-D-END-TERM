export const data = [
  {
    firstName: "Eminem",
    lastName: "",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://i.scdn.co/image/ab6761610000e5eba00b11c129b27a88fc72f36b",
    subject:"music",
    rating:"5",
    price:"2000",
    description:"Marshall Bruce Mathers III (born October 17, 1972), known professionally as Eminem (/ˌɛmɪˈnɛm/; stylized as EMINƎM), is an American rapper and record producer. He is credited with popularizing hip hop in middle America and is critically acclaimed as one of the greatest rappers of all time.[2] Eminem's global success and acclaimed works are widely regarded as having broken racial barriers for the acceptance of white rappers in popular music. While much of his transgressive work during the late 1990s and early 2000s made him widely controversial, he came to be a representation of popular angst of the American underclass and has been cited as an influence for many artists of various genres."
  },
  {
    firstName: "Albert",
    lastName: "Einstein",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://parade.com/.image/t_share/MTkwNTgwOTUyNjU2Mzg5MjQ1/albert-einstein-quotes-jpg.jpg",
    subject:"Physics",
    rating:"5",
    price:"2000",
    description:"Albert Einstein (/anstan/ EYEN-styne;[6] German: [albɛʁtbanʃtan] (listen); 14 March 1879  18 April 1955) was a German-born theoretical physicist,[7] widely acknowledged to be one of the greatest and most influential physicists of all time. Einstein is best known for developing the theory of relativity, but he also made important contributions to the development of the theory of quantum mechanics. Relativity and quantum mechanics are together the two pillars of modern physics.[3][8] His mass energy equivalence formula E = mc2, which arises from relativity theory, has been dubbed the world's most famous equation.[9] His work is also known for its influence on the philosophy of science.[10][11] He received the 1921 Nobel Prize in Physics for his services to theoretical physics, and especially for his discovery of the law of the photoelectric effect a pivotal step in the development of quantum theory. His intellectual achievements and originality resulted in Einstein becoming synonymous with genius"
  },
  {
    firstName: "Virat",
    lastName: "Kohli",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
      imageUrl: "https://www.indiancricketfans.com/uploads/monthly_2019_04/IMG-20190410-WA0001.jpg.8bce248a954fe32a1516e2350d3ea48e.jpg",
      subject:"Cricket",
      rating:"5",
      price:"2000",
      description:"Virat Kohli (Hindi: [ʋɪˈɾɑːʈ ˈkoːɦliː] (listen); born 5 November[3] 1988) is an Indian international cricketer and former captain of the India national cricket team. He plays for Delhi in domestic cricket and Royal Challengers Bangalore in the Indian Premier League as a right-handed batsman.Kohli made his Test debut in 2011. He reached the number one spot in the ICC rankings for ODI batsmen for the first time in 2013.  He has won Man of the Tournament twice at the ICC World Twenty20 (in 2014 and 2016). He also holds the world record of being the fastest to score 23,000 international career runs."
  },
  {
    firstName: "Giga",
    lastName: "Chad",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://melmagazine.com/wp-content/uploads/2021/01/66f-1.jpg",
    subject:"Workout",
    rating:"5",
    price:"2000",
    description:"“Giga Chad” or “Gigachad” refers to a character that is the ultimate Chad. He is usually represented by the male models featured in art project SleekNTe ars (YouTube, Instagram), which is the brainchild of Russian photographer Krista Sudmalis. The artwork features a lot of burly and scantily clad men and has an emphasis on muscle, fitness, and acrobatics. The most famous and widely used of these men is the model Ernest Khalimov who uses Instagram under the name berlin.1969. His image appears in a number of spin-off memes and has become synonymous with Chad."
  },
  {
    firstName: "Elon",
    lastName: "Musk",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Elon_Musk_Royal_Society_%28crop2%29.jpg/1200px-Elon_Musk_Royal_Society_%28crop2%29.jpg",
    subject:"Space Travel",
    rating:"5",
    price:"2000",
    description:"Elon Reeve Musk FRS (/ˈiːlɒn/ EE-lon; born June 28, 1971) is a business magnate and investor. He is the founder, CEO, and chief engineer of SpaceX; angel investor, CEO, and product architect of Tesla, Inc.; founder of The Boring Company; and co-founder of Neuralink and OpenAI. With an estimated net worth of around $210 billion as of October 26, 2022,[4] Musk is the wealthiest person in the world according to both the Bloomberg Billionaires Index and Forbes' real-time billionaires list.[5][6]"
  },
  {
    firstName: "Neil deGrasse",
    lastName: "Tyson",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Neil_deGrasse_Tyson_in_June_2017_%28cropped%29.jpg/800px-Neil_deGrasse_Tyson_in_June_2017_%28cropped%29.jpg",
    subject:"Astro Physics",
    rating:"5",
    price:"2000",
    description:"Neil deGrasse Tyson (US: /dəˈɡræs/ or UK: /dəˈɡrɑːs/; born October 5, 1958) is an American astrophysicist, author, and science communicator. Tyson studied at Harvard University, the University of Texas at Austin, and Columbia University. From 1991 to 1994, he was a postdoctoral research associate at Princeton University. In 1994, he joined the Hayden Planetarium as a staff scientist and the Princeton faculty as a visiting research scientist and lecturer. In 1996, he became director of the planetarium and oversaw its $210 million reconstruction project, which was completed in 2000. Since 1996, he has been the director of the Hayden Planetarium at the Rose Center for Earth and Space in New York City. The center is part of the American Museum of Natural History, where Tyson founded the Department of Astrophysics in 1997 and has been a research associate in the department since 2003.",

  },
  {
    firstName: "Vsauce",
    lastName: "",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://assets.nautil.us/13883_232362afef787e622e4d148d7630445a.jpg",
    subject:"Science",
    rating:"5",
    price:"2000",
    description:"Vsauce (/ˈviːsɔːs/) is a YouTube brand created by educator Michael Stevens.[3] The channels feature videos on scientific, psychological, mathematical, and philosophical topics, as well as gaming, technology, popular culture, and other general interest subjects.[4][5]"
  },
  {
    firstName: "MKBHD",
    lastName: "",
    about:
      "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Enim hjebhh jebfueb ujebfuien ujebfuie ehfuerfn buiehfuienf eiebhfeihfef eifhienfeif efuiebhfienf eferif cebfiefn c eihfie cie ciehfi e fiegf",
    imageUrl: "https://yt3.ggpht.com/lkH37D712tiyphnu0Id0D5MwwQ7IRuwgQLVD05iMXlDWO-kDHut3uI4MgIEAQ9StK0qOST7fiA=s900-c-k-c0x00ffffff-no-rj",
    subject:"Tech",
    rating:"5",
    price:"2000",
    description:"Marques Keith Brownlee[6][7] (/mrkɛz kiθ braʊnli/ mar-KEZ KEY-th BROWN-lee; born December 3, 1993), also known professionally as MKBHD, is an American YouTuber and professional ultimate Frisbee player, best known for his technology-focused videos as well as his podcast Waveform.[8] As of August 19, 2022, he has over 16 million subscribers and over 3 billion total video views. Vic Gundotra, a former senior vice president of Google,[9] called Brownlee 'the best technology reviewer on the planet right now. The former name of his YouTube channel is a concatenation of MKB (Brownlee's initials) and HD (for high-definition).[10] With New York PoNY, he is the 2022 WFDF World Champion in the Open Category for ultimate Frisbee.[12]"
  },
];
